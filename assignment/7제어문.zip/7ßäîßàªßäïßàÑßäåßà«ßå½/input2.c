#include <stdio.h>

void main(){

	int a, b, i;
		
		puts("write two numbers");
		scanf("%d %d", &a, &b);


		for(i=a; i<=b; i++){
				printf(" %d ", i);
		}


	

}
