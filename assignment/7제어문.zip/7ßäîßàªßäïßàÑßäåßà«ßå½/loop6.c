#include <stdio.h>

void main(){

		
	int a[5];
		
	void main(){

		scanf("%d %d %d %d %d", &a[0], &a[1], &a[2], &a[3], &a[4]);

	}



/*
	int i, j;

	// 6번

	for(i=0; i<5; i++){

			for(j=0; j<5; j++)
					((j+i)%2)==0?printf("$"):printf("#");
			
			puts("");

	}
*/
}
